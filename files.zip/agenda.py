"""
Agenda Funcional - Tema Rosa & Roxo 💀🦴
==========================================
Aplicação de agenda com interface gráfica (tkinter) em tons de rosa
e roxo, com caveirinhas animadas decorativas. Permite cadastrar,
editar, excluir e buscar compromissos. Os dados são salvos em um
arquivo JSON local (agenda_dados.json), no mesmo diretório do script.

Como executar:
    python agenda.py

Observação sobre as caveirinhas:
    O arquivo "caveira.gif" precisa estar na mesma pasta do
    agenda.py. Se ele não for encontrado, a agenda funciona
    normalmente, só sem a animação.
"""

import json
import os
from datetime import datetime
import tkinter as tk
from tkinter import ttk, messagebox

DIRETORIO_BASE = os.path.dirname(os.path.abspath(__file__))
ARQUIVO_DADOS = os.path.join(DIRETORIO_BASE, "agenda_dados.json")
ARQUIVO_GIF = os.path.join(DIRETORIO_BASE, "caveira.gif")


# ----------------------------------------------------------------------
# Paleta de cores - Rosa & Roxo
# ----------------------------------------------------------------------
CORES = {
    "roxo_escuro": "#2d1b4e",
    "roxo": "#6a4c93",
    "roxo_claro": "#9b7fc7",
    "rosa_forte": "#d63384",
    "rosa": "#ff6fae",
    "rosa_claro": "#ffd6ea",
    "branco_rosado": "#fff5fb",
}


# ----------------------------------------------------------------------
# Caveirinha animada (usa tk.PhotoImage nativo, sem dependências extras)
# ----------------------------------------------------------------------
class CaveiraAnimada(tk.Label):
    """Label que exibe um GIF de caveirinha animando em loop."""

    def __init__(self, master, caminho_gif=ARQUIVO_GIF, intervalo_ms=180, **kwargs):
        kwargs.setdefault("bg", CORES["roxo_escuro"])
        super().__init__(master, **kwargs)
        self.intervalo_ms = intervalo_ms
        self.quadros = self._carregar_quadros(caminho_gif)
        self.indice = 0
        if self.quadros:
            self.configure(image=self.quadros[0])
            self.after(self.intervalo_ms, self._proximo_quadro)

    def _carregar_quadros(self, caminho):
        quadros = []
        if not os.path.exists(caminho):
            return quadros
        i = 0
        while True:
            try:
                quadro = tk.PhotoImage(master=self, file=caminho, format=f"gif -index {i}")
            except tk.TclError:
                break
            quadros.append(quadro)
            i += 1
        return quadros

    def _proximo_quadro(self):
        if not self.quadros:
            return
        self.indice = (self.indice + 1) % len(self.quadros)
        self.configure(image=self.quadros[self.indice])
        self.after(self.intervalo_ms, self._proximo_quadro)


# ----------------------------------------------------------------------
# Camada de dados
# ----------------------------------------------------------------------
class RepositorioAgenda:
    """Responsável por carregar e salvar os compromissos em disco."""

    def __init__(self, caminho_arquivo):
        self.caminho_arquivo = caminho_arquivo
        self.compromissos = []
        self.carregar()

    def carregar(self):
        if os.path.exists(self.caminho_arquivo):
            try:
                with open(self.caminho_arquivo, "r", encoding="utf-8") as f:
                    self.compromissos = json.load(f)
            except (json.JSONDecodeError, OSError):
                self.compromissos = []
        else:
            self.compromissos = []

    def salvar(self):
        with open(self.caminho_arquivo, "w", encoding="utf-8") as f:
            json.dump(self.compromissos, f, ensure_ascii=False, indent=2)

    def adicionar(self, compromisso):
        novo_id = max([c["id"] for c in self.compromissos], default=0) + 1
        compromisso["id"] = novo_id
        self.compromissos.append(compromisso)
        self.salvar()

    def atualizar(self, id_compromisso, dados_novos):
        for c in self.compromissos:
            if c["id"] == id_compromisso:
                c.update(dados_novos)
                break
        self.salvar()

    def excluir(self, id_compromisso):
        self.compromissos = [c for c in self.compromissos if c["id"] != id_compromisso]
        self.salvar()

    def listar_ordenados(self):
        def chave(c):
            return (c["data"], c["hora"])
        return sorted(self.compromissos, key=chave)


# ----------------------------------------------------------------------
# Estilo visual (rosa & roxo)
# ----------------------------------------------------------------------
def aplicar_tema(root):
    root.configure(bg=CORES["roxo_escuro"])

    estilo = ttk.Style(root)
    if "clam" in estilo.theme_names():
        estilo.theme_use("clam")

    estilo.configure("TFrame", background=CORES["roxo_escuro"])

    estilo.configure(
        "TLabel",
        background=CORES["roxo_escuro"],
        foreground=CORES["rosa_claro"],
        font=("Segoe UI", 10),
    )
    estilo.configure(
        "Titulo.TLabel",
        background=CORES["roxo_escuro"],
        foreground=CORES["rosa"],
        font=("Segoe UI", 16, "bold"),
    )

    estilo.configure(
        "TButton",
        background=CORES["rosa_forte"],
        foreground=CORES["branco_rosado"],
        font=("Segoe UI", 10, "bold"),
        padding=6,
        borderwidth=0,
    )
    estilo.map(
        "TButton",
        background=[("active", CORES["roxo_claro"]), ("pressed", CORES["roxo"])],
        foreground=[("active", CORES["branco_rosado"])],
    )

    estilo.configure(
        "TEntry",
        fieldbackground=CORES["branco_rosado"],
        foreground=CORES["roxo_escuro"],
        insertcolor=CORES["roxo_escuro"],
        padding=4,
    )

    estilo.configure(
        "Treeview",
        background=CORES["rosa_claro"],
        fieldbackground=CORES["rosa_claro"],
        foreground=CORES["roxo_escuro"],
        rowheight=26,
        font=("Segoe UI", 10),
    )
    estilo.configure(
        "Treeview.Heading",
        background=CORES["roxo"],
        foreground=CORES["branco_rosado"],
        font=("Segoe UI", 10, "bold"),
    )
    estilo.map(
        "Treeview",
        background=[("selected", CORES["rosa_forte"])],
        foreground=[("selected", CORES["branco_rosado"])],
    )

    estilo.configure(
        "Vertical.TScrollbar",
        background=CORES["roxo"],
        troughcolor=CORES["roxo_escuro"],
        arrowcolor=CORES["branco_rosado"],
    )


# ----------------------------------------------------------------------
# Interface gráfica
# ----------------------------------------------------------------------
class AgendaApp:
    def __init__(self, root):
        self.root = root
        self.root.title("💀 Agenda Funcional 🦴")
        self.root.geometry("800x520")
        self.root.minsize(700, 440)

        aplicar_tema(self.root)

        self.repo = RepositorioAgenda(ARQUIVO_DADOS)
        self.id_selecionado = None

        self._montar_layout()
        self._atualizar_tabela()

    # ---------------- layout ----------------
    def _montar_layout(self):
        # Cabeçalho com título e caveirinhas decorativas
        frame_cabecalho = ttk.Frame(self.root, padding=(10, 10, 10, 0))
        frame_cabecalho.pack(fill="x")

        CaveiraAnimada(frame_cabecalho).pack(side="left", padx=(0, 10))
        ttk.Label(frame_cabecalho, text="Agenda Funcional", style="Titulo.TLabel").pack(side="left")
        CaveiraAnimada(frame_cabecalho).pack(side="right", padx=(10, 0))

        # Barra de busca
        frame_busca = ttk.Frame(self.root, padding=10)
        frame_busca.pack(fill="x")

        ttk.Label(frame_busca, text="Buscar:").pack(side="left")
        self.var_busca = tk.StringVar()
        self.var_busca.trace_add("write", lambda *args: self._atualizar_tabela())
        ttk.Entry(frame_busca, textvariable=self.var_busca, width=40).pack(side="left", padx=5)

        ttk.Button(frame_busca, text="✨ Novo Compromisso", command=self._abrir_form_novo).pack(side="right")

        # Tabela de compromissos
        frame_tabela = ttk.Frame(self.root, padding=(10, 0))
        frame_tabela.pack(fill="both", expand=True)

        colunas = ("data", "hora", "titulo", "descricao")
        self.tabela = ttk.Treeview(frame_tabela, columns=colunas, show="headings", selectmode="browse")
        self.tabela.heading("data", text="Data")
        self.tabela.heading("hora", text="Hora")
        self.tabela.heading("titulo", text="Título")
        self.tabela.heading("descricao", text="Descrição")

        self.tabela.column("data", width=90, anchor="center")
        self.tabela.column("hora", width=60, anchor="center")
        self.tabela.column("titulo", width=180)
        self.tabela.column("descricao", width=350)

        scrollbar = ttk.Scrollbar(frame_tabela, orient="vertical", command=self.tabela.yview)
        self.tabela.configure(yscrollcommand=scrollbar.set)

        self.tabela.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        self.tabela.bind("<Double-1>", lambda e: self._abrir_form_editar())

        # Botões de ação
        frame_botoes = ttk.Frame(self.root, padding=10)
        frame_botoes.pack(fill="x")

        ttk.Button(frame_botoes, text="✏️ Editar", command=self._abrir_form_editar).pack(side="left")
        ttk.Button(frame_botoes, text="🗑️ Excluir", command=self._excluir_selecionado).pack(side="left", padx=5)

    # ---------------- tabela ----------------
    def _atualizar_tabela(self):
        for item in self.tabela.get_children():
            self.tabela.delete(item)

        termo = self.var_busca.get().strip().lower()

        for c in self.repo.listar_ordenados():
            texto_busca = f'{c["titulo"]} {c["descricao"]} {c["data"]}'.lower()
            if termo and termo not in texto_busca:
                continue
            self.tabela.insert(
                "", "end", iid=str(c["id"]),
                values=(c["data"], c["hora"], c["titulo"], c["descricao"])
            )

    def _obter_id_selecionado(self):
        selecao = self.tabela.selection()
        if not selecao:
            return None
        return int(selecao[0])

    def _excluir_selecionado(self):
        id_sel = self._obter_id_selecionado()
        if id_sel is None:
            messagebox.showinfo("Agenda", "Selecione um compromisso para excluir.")
            return
        if messagebox.askyesno("Confirmar exclusão", "Deseja realmente excluir este compromisso? 💀"):
            self.repo.excluir(id_sel)
            self._atualizar_tabela()

    # ---------------- formulário ----------------
    def _abrir_form_novo(self):
        FormCompromisso(self.root, self, compromisso=None)

    def _abrir_form_editar(self):
        id_sel = self._obter_id_selecionado()
        if id_sel is None:
            messagebox.showinfo("Agenda", "Selecione um compromisso para editar.")
            return
        compromisso = next((c for c in self.repo.compromissos if c["id"] == id_sel), None)
        if compromisso:
            FormCompromisso(self.root, self, compromisso=compromisso)


class FormCompromisso(tk.Toplevel):
    """Janela de formulário para criar ou editar um compromisso."""

    def __init__(self, parent, app: AgendaApp, compromisso=None):
        super().__init__(parent)
        self.app = app
        self.compromisso = compromisso
        self.title(("💀 Editar Compromisso" if compromisso else "🦴 Novo Compromisso"))
        self.geometry("400x420")
        self.resizable(False, False)
        self.configure(bg=CORES["roxo_escuro"])
        self.transient(parent)
        self.grab_set()

        self._montar_form()
        if compromisso:
            self._preencher(compromisso)

    def _montar_form(self):
        pad = {"padx": 10, "pady": 6}

        CaveiraAnimada(self).pack(pady=(10, 0))

        ttk.Label(self, text="Data (DD/MM/AAAA):").pack(anchor="w", **pad)
        self.var_data = tk.StringVar()
        ttk.Entry(self, textvariable=self.var_data).pack(fill="x", padx=10)

        ttk.Label(self, text="Hora (HH:MM):").pack(anchor="w", **pad)
        self.var_hora = tk.StringVar()
        ttk.Entry(self, textvariable=self.var_hora).pack(fill="x", padx=10)

        ttk.Label(self, text="Título:").pack(anchor="w", **pad)
        self.var_titulo = tk.StringVar()
        ttk.Entry(self, textvariable=self.var_titulo).pack(fill="x", padx=10)

        ttk.Label(self, text="Descrição:").pack(anchor="w", **pad)
        self.texto_descricao = tk.Text(
            self, height=5,
            bg=CORES["branco_rosado"], fg=CORES["roxo_escuro"],
            insertbackground=CORES["roxo_escuro"],
            relief="flat", padx=6, pady=6,
        )
        self.texto_descricao.pack(fill="x", padx=10)

        frame_botoes = ttk.Frame(self)
        frame_botoes.pack(pady=15)
        ttk.Button(frame_botoes, text="💗 Salvar", command=self._salvar).pack(side="left", padx=5)
        ttk.Button(frame_botoes, text="Cancelar", command=self.destroy).pack(side="left", padx=5)

    def _preencher(self, c):
        data_br = datetime.strptime(c["data"], "%Y-%m-%d").strftime("%d/%m/%Y")
        self.var_data.set(data_br)
        self.var_hora.set(c["hora"])
        self.var_titulo.set(c["titulo"])
        self.texto_descricao.insert("1.0", c["descricao"])

    def _validar_e_obter_dados(self):
        data_str = self.var_data.get().strip()
        hora_str = self.var_hora.get().strip()
        titulo = self.var_titulo.get().strip()
        descricao = self.texto_descricao.get("1.0", "end").strip()

        if not titulo:
            messagebox.showerror("Erro", "O título é obrigatório.")
            return None

        try:
            data_iso = datetime.strptime(data_str, "%d/%m/%Y").strftime("%Y-%m-%d")
        except ValueError:
            messagebox.showerror("Erro", "Data inválida. Use o formato DD/MM/AAAA.")
            return None

        try:
            datetime.strptime(hora_str, "%H:%M")
        except ValueError:
            messagebox.showerror("Erro", "Hora inválida. Use o formato HH:MM.")
            return None

        return {
            "data": data_iso,
            "hora": hora_str,
            "titulo": titulo,
            "descricao": descricao,
        }

    def _salvar(self):
        dados = self._validar_e_obter_dados()
        if dados is None:
            return

        if self.compromisso:
            self.app.repo.atualizar(self.compromisso["id"], dados)
        else:
            self.app.repo.adicionar(dados)

        self.app._atualizar_tabela()
        self.destroy()


def main():
    root = tk.Tk()
    AgendaApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
